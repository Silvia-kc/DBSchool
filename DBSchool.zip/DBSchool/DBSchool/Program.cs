﻿// See https://aka.ms/new-console-template for more information
using DBSchool;
using Microsoft.Data.SqlClient;
using System.ComponentModel.Design;
string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
using (SqlConnection con = new SqlConnection(connectionString))
{
    con.Open();

    string checkDbQuery = "IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'SchoolDB') CREATE DATABASE SchoolDB;";
    ExecuteQuery(con, checkDbQuery);
    Console.WriteLine("Database is created or already exists!");

    con.ChangeDatabase("SchoolDB");

    CreateTables(con);
    Console.WriteLine("The tables are created!");

    InsertTeachers(con);
    InsertClassrooms(con);
    InsertClasses(con);
    InsertStudents(con);
    InsertParents(con);

    new Logger().Log("Database setup complete.");
    Console.WriteLine("Logging complete.");

    DatabaseQueries dbQueries = new DatabaseQueries();

    while (true)
    {
        Console.WriteLine("\nSelect a request to execute:");
        Console.WriteLine("1. Names of students from class 11B");
        Console.WriteLine("2. Teachers and subjects");
        Console.WriteLine("3. Classes and class teachers");
        Console.WriteLine("4. Number of subject teachers");
        Console.WriteLine("5.Classrooms with a capacity of over 26 students");
        Console.WriteLine("6. Students grouped by class");
        Console.WriteLine("7. Entered class students");
        Console.WriteLine("8.Students born on date entered");
        Console.WriteLine("9.Number of subjects per student");
        Console.WriteLine("10. Teachers and subjects per student");
        Console.WriteLine("11. Parent's Children's Classes (by email)");
        Console.WriteLine("0.Exit");
        Console.Write("Enter request number: ");

        string choice = Console.ReadLine();
        Console.WriteLine();

        switch (choice)
        {
            case "1":
                dbQueries.GetStudentsFromClass("11", "Б");
                break;
            case "2":
                dbQueries.GetTeachersBySubjects();
                break;
            case "3":
                dbQueries.GetClassesAndTeachers();
                break;
            case "4":
                dbQueries.GetSubjectsTeacherCount();
                break;
            case "5":
                dbQueries.GetLargeClassrooms();
                break;
            case "6":
                dbQueries.GetAllStudentsGroupedByClass();
                break;
            case "7":
                Console.Write("Enter class number: ");
                string classNumber = Console.ReadLine();
                Console.Write("Enter class letter: ");
                string classLetter = Console.ReadLine();
                dbQueries.GetStudentsFromClass(classNumber, classLetter);
                break;
            case "8":
                Console.Write("Enter date of birth : ");
                string birthDate = Console.ReadLine();
                dbQueries.GetStudentsByBirthDate(birthDate);
                break;
            case "9":
                Console.Write("Enter student name: ");
                string studentName1 = Console.ReadLine();
                dbQueries.GetSubjectsByStudent(studentName1);
                break;
            case "10":
                Console.Write("Enter student name: ");
                string studentName2 = Console.ReadLine();
                dbQueries.GetTeachersByStudent(studentName2);
                break;
            case "11":
                Console.Write("Enter Parent Email:");
                string parentEmail = Console.ReadLine();
                dbQueries.GetClassesByParentEmail(parentEmail);
                break;
            case "0":
                Console.WriteLine("Exit...");
                return;
        }
     }
}
static void CreateTables(SqlConnection con)
{
    ExecuteQuery(con, @"CREATE TABLE teachers(
            id INT PRIMARY KEY IDENTITY(1,1),
            teacher_code VARCHAR(10) UNIQUE NOT NULL,
            full_name NVARCHAR(100) NOT NULL,
            gender NVARCHAR(10),
            date_of_birth DATE,
            email NVARCHAR(100),
            phone NVARCHAR(20),
            working_days NVARCHAR(50)
);");
    ExecuteQuery(con, @"CREATE TABLE subjects (
            id INT PRIMARY KEY IDENTITY(1,1),
            title NVARCHAR(100) NOT NULL
);");
    ExecuteQuery(con, @"CREATE TABLE classrooms (
            id INT PRIMARY KEY IDENTITY(1,1)T,
            floor INT NOT NULL,
            capacity INT NOT NULL,
            description NVARCHAR(500)
);");
    ExecuteQuery(con, @"CREATE TABLE classes (
            id INT PRIMARY KEY IDENTITY(1,1),
            class_number INT NOT NULL,
            class_letter NVARCHAR(1) NOT NULL,
            class_teacher_id INT FOREIGN KEY REFERENCES teachers(id),
            classroom_id INT FOREIGN KEY REFERENCES classrooms(id)
);");
    ExecuteQuery(con, @"CREATE TABLE students (
            id INT PRIMARY KEY IDENTITY(1,1),
            student_code NVARCHAR(10) UNIQUE NOT NULL,
            full_name NVARCHAR(100) NOT NULL,
            gender NVARCHAR(10),
            date_of_birth DATE,
            email NVARCHAR(100),
            phone NVARCHAR(20),
            class_id INT FOREIGN KEY REFERENCES classes(id),
            is_active BIT DEFAULT 1
);");
    ExecuteQuery(con, @"CREATE TABLE parents (
            id INT PRIMARY KEY IDENTITY(1,1),
            parent_code NVARCHAR(10) UNIQUE NOT NULL,
            full_name NVARCHAR(100) NOT NULL,
            email NVARCHAR(100),
            phone VARCHAR(20)
);");
    ExecuteQuery(con, @"CREATE TABLE teachers_subjects (
            id INT PRIMARY KEY IDENTITY(1,1),
            teacher_id INT FOREIGN KEY REFERENCES teachers(id),
            subject_id INT FOREIGN KEY REFERENCES subjects(id)
);");
    ExecuteQuery(con, @"CREATE TABLE classes_subjects (
            id INT PRIMARY KEY AUTO_INCREMENT,
            class_id INT FOREIGN KEY REFERENCES classes(id),
            subject_id INT FOREIGN KEY REFERENCES subjects(id)
);");
    ExecuteQuery(con, @"CREATE TABLE students_parents (
            id INT PRIMARY KEY IDENTITY(1,1),
            student_id INT FOREIGN KEY REFERENCES students(id),
            parent_id  INT FOREIGN KEY REFERENCES parents(id)
);");
}
static void InsertTeachers(SqlConnection con)
{
    for (int i = 0; i < 5; i++)
    {
        Console.Write("Enter teacher code: ");
        string teacherCode = Console.ReadLine();

        Console.Write("Enter teacher's name: ");
        string fullName = Console.ReadLine();

        Console.Write("Enter genre: ");
        string gender = Console.ReadLine();

        Console.Write("Enter date of birth: ");
        string dateOfBirth = Console.ReadLine();

        Console.Write("Enter email: ");
        string email = Console.ReadLine();

        Console.Write("Enter phone number: ");
        string phone = Console.ReadLine();

        Console.Write("Enter working days: ");
        string workingDays = Console.ReadLine();

        string insertTeacherQuery = @"INSERT INTO teachers (teacher_code, full_name, gender, date_of_birth, email, phone, working_days) 
                              VALUES (@teacher_code, @full_name, @gender, @date_of_birth, @email, @phone, @working_days);";

        using (SqlCommand command = new SqlCommand(insertTeacherQuery, con))
        {
            command.Parameters.AddWithValue("@teacher_code", teacherCode);
            command.Parameters.AddWithValue("@full_name", fullName);
            command.Parameters.AddWithValue("@gender", gender);
            command.Parameters.AddWithValue("@date_of_birth", dateOfBirth);
            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@phone", phone);
            command.Parameters.AddWithValue("@working_days", workingDays);
            command.ExecuteNonQuery();
        }
    }
}
static void InsertClassrooms(SqlConnection con)
{
    for (int i = 0; i < 5; i++)
    {
        Console.Write("Enter floor: ");
        int floor = int.Parse(Console.ReadLine());
        Console.Write("Enter capacity: ");
        int capacity = int.Parse(Console.ReadLine());
        Console.Write("Description: ");
        string description = Console.ReadLine();

        string query = "INSERT INTO classrooms (floor, capacity, description) " +
            "VALUES (@floor, @capacity, @description);";
        using (SqlCommand command = new SqlCommand(query, con))
        {
            command.Parameters.AddWithValue("@floor", floor);
            command.Parameters.AddWithValue("@capacity", capacity);
            command.Parameters.AddWithValue("@description", description);
            command.ExecuteNonQuery();
        }
    }
}
static void InsertClasses(SqlConnection con)
{
    for (int i = 0; i < 5; i++)
    {
        Console.Write("Enter class number: ");
        int classNumber = int.Parse(Console.ReadLine());
        Console.Write("Enter class letter: ");
        string classLetter = Console.ReadLine();

        string query = "INSERT INTO classes (class_number, class_letter, class_teacher_id, classroom_id) " +
            "VALUES (@number, @letter, 1, 1);";

        using (SqlCommand command = new SqlCommand(query, con))
        {
            command.Parameters.AddWithValue("@number", classNumber);
            command.Parameters.AddWithValue("@letter", classLetter);
            command.ExecuteNonQuery();
        }
    }
}
static void InsertStudents(SqlConnection con)
{
    Console.Write("Enter student code: ");
    string studentCode = Console.ReadLine();
    Console.Write("Enter student's full name: ");
    string fullName = Console.ReadLine();
    Console.Write("Enter gender: ");
    string gender = Console.ReadLine();
    Console.Write("Enter date of birth: ");
    string dateOfBirth = Console.ReadLine();
    Console.Write("Enter email: ");
    string email = Console.ReadLine();
    Console.Write("Enter phone: ");
    string phone = Console.ReadLine();
    Console.Write("Enter class id: ");
    int classId = int.Parse(Console.ReadLine());
    Console.Write("Is the student active? (1 - Yes, 0 - No): ");
    bool isActive = Console.ReadLine() == "1";
    
    string query = @"INSERT INTO students (student_code, full_name, gender, date_of_birth, email, phone, class_id, is_active) 
                              VALUES (@student_code, @full_name, @gender, @date_of_birth, @email, @phone, @class_id, @is_active);";

    using (SqlCommand command = new SqlCommand(query, con))
    {
        command.Parameters.AddWithValue("@student_code", studentCode);
        command.Parameters.AddWithValue("@full_name", fullName);
        command.Parameters.AddWithValue("@gender", gender);
        command.Parameters.AddWithValue("@date_of_birth", dateOfBirth);
        command.Parameters.AddWithValue("@email", email);
        command.Parameters.AddWithValue("@phone", phone);
        command.Parameters.AddWithValue("@class_id", classId);
        command.Parameters.AddWithValue("@is_active", isActive);
        command.ExecuteNonQuery();
    }
}
static void InsertParents(SqlConnection con)
{
    Console.Write("Enter parent code: ");
    string parentCode= Console.ReadLine();
    Console.Write("Enter parent's full name: ");
    string fullName = Console.ReadLine();
    Console.Write("Enter email: ");
    string email = Console.ReadLine();
    Console.Write("Enter phone number: ");
    string phone = Console.ReadLine();

    
    string query = @"INSERT INTO parents (parent_code, full_name, email, phone) 
                                 VALUES (@parent_code, @full_name, @email, @phone);";

    using (SqlCommand command = new SqlCommand(query, con))
    {
        command.Parameters.AddWithValue("@parent_code", parentCode);
        command.Parameters.AddWithValue("@full_name", fullName);
        command.Parameters.AddWithValue("@email", email);
        command.Parameters.AddWithValue("@phone", phone);
        command.ExecuteNonQuery();
    }
}
static void ExecuteQuery(SqlConnection con, string query)
{
    using (SqlCommand cmd = new SqlCommand(query, con))
    {
        cmd.ExecuteNonQuery();
    }
}